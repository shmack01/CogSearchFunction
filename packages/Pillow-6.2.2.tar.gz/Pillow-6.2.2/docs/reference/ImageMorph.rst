.. py:module:: PIL.ImageMorph
.. py:currentmodule:: PIL.ImageMorph

:py:mod:`ImageMorph` Module
===========================

The :py:mod:`ImageMorph` module provides morphology operations on images.

.. automodule:: PIL.ImageMorph
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:
