from __future__ import print_function

import glob
import os
import sys
import traceback

sys.path.insert(0, ".")

for file in glob.glob("src/PIL/*.py"):
    module = os.path.basename(file)[:-3]
    try:
        exec("from PIL import " + module)
    except (ImportError, SyntaxError):
        print("===", "failed to import", module)
        traceback.print_exc()
