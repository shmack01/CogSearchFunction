#!/usr/bin/env python

import real_browse
import os
os.chdir('/usr/share/doc/python')
real_browse.main()
