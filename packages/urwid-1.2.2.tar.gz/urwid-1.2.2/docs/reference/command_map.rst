Command Map
-----------

.. currentmodule:: urwid

.. autoclass:: CommandMap
